# idshwk4
zeeeek

the unique count of url response 404   uri设置为观察strings

key$host是一个扫描器，在reply404$unique个URL上尝试了reply404$sum次扫描

count类型无法用于运算，（$num）double可以用于运算（$sum）
